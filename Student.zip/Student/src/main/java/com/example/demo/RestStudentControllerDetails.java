package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/students")
public class RestStudentControllerDetails {

    @Autowired
    private StudentService studentService;

    @GetMapping
    public Page<StudentDetails> list(@RequestParam(defaultValue = "0") int page) {
        return studentService.listAll(page, 5);
    }

    @GetMapping("/{id}")
    public Optional<StudentDetails> get(@PathVariable Long id) {
        return studentService.get(id);
    }

    @PostMapping
    public StudentDetails create(@RequestBody StudentDetails student) {
        return studentService.save(student);
    }

    @PutMapping("/{id}")
    public StudentDetails update(@PathVariable Long id, @RequestBody StudentDetails student) {
        student.setStudentId(id);
        return studentService.save(student);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        studentService.delete(id);
    }

    @GetMapping("/search")
    public Page<StudentDetails> search(@RequestParam String name, @RequestParam(defaultValue = "0") int page) {
        return studentService.searchByName(name, page, 5);
    }
}
