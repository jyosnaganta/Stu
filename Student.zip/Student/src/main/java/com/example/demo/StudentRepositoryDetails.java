package com.example.demo;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepositoryDetails extends JpaRepository<StudentDetails, Long> {
    Page<StudentDetails> findByNameContainingIgnoreCase(String name, Pageable pageable);
    Page<StudentDetails> findByClassName(String className, Pageable pageable);
}
